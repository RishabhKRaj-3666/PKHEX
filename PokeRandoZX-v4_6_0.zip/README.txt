1. HOW TO USE

Just double click the launcher script that matches your operating system and it will start the randomizer program.

Windows: Use launcher_WINDOWS.bat
Mac: Use launcher_MAC.command
Other Unix-based systems: Use launcher_UNIX.sh

DO NOT change the name of the randomizer program as this will cause the launcher to fail.
The launcher program and the randomizer program must be in the same folder.
The launcher is necessary for being able to randomize 3DS games.


2. TROUBLESHOOTING

Please go here if you run into problems with the launcher and need help:

https://github.com/Ajarmar/universal-pokemon-randomizer-zx/issues/221